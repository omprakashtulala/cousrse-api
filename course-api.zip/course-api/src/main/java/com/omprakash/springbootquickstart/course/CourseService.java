package com.omprakash.springbootquickstart.course;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseService {

	@Autowired
	private CourseRepository courseRepository;
	
	/*private List<Topic> topics = new ArrayList<>(Arrays.asList(
			new Topic("spring", "Spring Framework", "Spring framework description."),
			new Topic("java", "Core Java", "Core Java description."),
			new Topic("php", "Core PHP", "Core PHP description.")
			));
	*/
	public List<Course> getAllcourses(String topicId) {
		return (List<Course>) this.courseRepository.findByTopicId(topicId);
	}

	public Course getCourse(String id) {
		  Course t = this.courseRepository.findById(id).get();
		  return t;
		 }

	public void addCourse(Course course) {
		this.courseRepository.save(course);
	}

	public void updateCourse(Course course) {
		this.courseRepository.save(course);
	}

	public void deleteCourse(String id) {
		this.courseRepository.deleteById(id);
	}
}
